# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 19:13:35 2023

@author: heps1

"""
import sys
import numpy as np
# append necessary file paths, and change E -> D or vice versa
 
from MeasurementInfo import MeasurementInfo
from RunInfo import RunInfo
import heapq
from scipy import signal
from scipy.optimize import curve_fit
import AnalyzePDE
from AnalyzePDE import SPE_data
from AnalyzePDE import Alpha_data
import matplotlib.pyplot as plt
import matplotlib as mpl
import ProcessWaveforms_MultiGaussian
from ProcessWaveforms_MultiGaussian import WaveformProcessor as WaveformProcessor
import csv
plt.style.use('D:/Xe/AnalysisScripts/LXe May 2023/nexo_new.mplstyle')

#%% 153K 
run_spe_solicited = RunInfo(['D:/Xe/DAQ/Run_1671538806.hdf5'],  specifyAcquisition = True, acquisition ='Acquisition_1671539683', do_filter = False, is_solicit = True, upper_limit = .5, baseline_correct = True)
files = ['Acquisition_1671538834', 'Acquisition_1671539031', 'Acquisition_1671539225', 'Acquisition_1671539462']
upperlim = [4.9, 4.9, 4.9, 4.9]
proms = [0.038, 0.038, 0.038, 0.038]
runs = []
for file in range(len(files)):
    run_spe = RunInfo(['D:/Xe/DAQ/Run_1671538806.hdf5'],  specifyAcquisition = True, acquisition = files[file], do_filter = False, upper_limit = upperlim[file], baseline_correct = True, prominence = proms[file])
    runs.append(run_spe)
biases = [run.bias for run in runs]
#%% gain calibration conversion factor (change as needed; make sure it is the correct factor for the data set)
invC_spe_filter = 0.19261918346201742 
invC_spe_err_filter = 0.0021831140214106596

#%%
for i in range(len(runs)):
    bias = biases[i]
    runs[i].plot_hists('151K', '0.3')
#%%
range_lows = [0.075, 0.072, 0.099, 0.11]
centers = [0.053, 0.05, 0.065, 0.075]
range_highs = [0.27, 0.2, 0.38, 0.43]
numpeaks = [4,4,5,5]
#%% plot with peak fit
# set  conditions, temp
n= 0
T = 153
con = 'GN'
info_spe = MeasurementInfo()
info_spe.condition = con
info_spe.date = runs[n].date
info_spe.temperature = T
info_spe.bias = biases[n]
info_spe.baseline_numbins = 50
info_spe.peaks_numbins = 200
info_spe.data_type = 'h5'
wp = WaveformProcessor(info_spe, run_info_self = runs[n], run_info_solicit = run_spe_solicited, baseline_correct = True, range_low = range_lows[n], range_high = range_highs[n], center = centers[n], peak_range = (2,numpeaks[n]))
wp.process(do_spe = True, do_alpha = False)
# wp.plot_peak_histograms()
wp.plot_spe()
# wp.plot_both_histograms()


#%%
campaign_spe = []
for i in range(len(runs)):
    # if i ==1:
    #     continue
    T = 153
    con = 'GN'
    info_spe = MeasurementInfo()
    info_spe.condition = con
    info_spe.date = runs[i].date
    info_spe.temperature = T
    # info_spe.bias = biases[i]
    info_spe.bias = runs[i].bias
    info_spe.baseline_numbins = 50
    info_spe.peaks_numbins = 200
    info_spe.data_type = 'h5'
    wp_spe = WaveformProcessor(info_spe, run_info_self = runs[i], run_info_solicit = run_spe_solicited, baseline_correct = True, range_low = range_lows[i], range_high = range_highs[i], center = centers[i], peak_range = (2,numpeaks[i]))
    wp_spe.process(do_spe = True, do_alpha = False)
    wp_spe.plot_spe()
    campaign_spe.append(wp_spe)
    
#%% plots
for i in range(len(campaign_spe)):
    campaign_spe[i].plot_peak_histograms()

#%%
curr_campaign = campaign_spe

filtered_spe = SPE_data(curr_campaign, invC_spe_filter, invC_spe_err_filter, filtered = False)
filtered_spe.plot_spe(in_ov = False, absolute = False, out_file = 'D:/Raw Results/Breakdown Voltage/SPE Amplitudes/Dec2022_153K_SPE.csv')

print(filtered_spe.v_bd)
print(filtered_spe.v_bd_err)

#%%
# curr_campaign = campaign_spe

# filtered_spe = SPE_data(curr_campaign, invC_spe_filter, invC_spe_err_filter, filtered = False)
# filtered_spe.plot_spe(in_ov = True, absolute = True, out_file = None)

# print(filtered_spe.v_bd)
# print(filtered_spe.v_bd_err)

path = 'D:/Xe/AnalysisScripts/Nitrogen Dark Run 2022/153K/'
for w in range(len(campaign_spe)):
    folder = path
    bias = biases[w]
    # wp_spe.plot_both_histograms(savefig = True, path = folder +'baseline_' + str(T)[:3] + '_' + str(bias)[:2] + '.png')
    # campaign_spe[w].plot_peak_histograms(savefig = True, path = folder +'gauss_' + str(T)[:3] + '_' + str(bias)[:2] + '_revision.png')
    campaign_spe[w].plot_spe(savefig = True, path = folder + 'line_' +str(T)[:3] + '_' + str(bias)[:2] + '_revision.png')
    # wp_spe.plot_both_histograms(savefig = True, path = folder +'baseline_' + str(T)[:3] + '_' + str(bias)[:2] + '.svg')
    # wp_spe.plot_peak_histograms(savefig = True, path = folder +'gauss_' + str(T)[:3] + '_' + str(bias)[:2] + '.svg')