# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 19:13:35 2023

@author: heps1
"""
import sys
import numpy as np
# append necessary file paths, and change E -> D or vice versa
# sys.path.append('/Users/albertwang/Desktop/nEXO')   
from MeasurementInfo import MeasurementInfo
from RunInfo import RunInfo
import heapq
from scipy import signal
from scipy.optimize import curve_fit
import AnalyzePDE
from AnalyzePDE import SPE_data
from AnalyzePDE import Alpha_data
import matplotlib.pyplot as plt
import matplotlib as mpl
import ProcessWaveforms_MultiGaussian
from ProcessWaveforms_MultiGaussian import WaveformProcessor as WaveformProcessor
import csv
plt.style.use('D:/Xe/AnalysisScripts/LXe May 2023/nexo_new.mplstyle')


#%% 158K
run_spe_solicited = RunInfo(['D:/Xe/DAQ/Run_1670927963.hdf5'],  specifyAcquisition = True, acquisition ='Acquisition_1670929481', do_filter = False, is_solicit = True, upper_limit = .5, baseline_correct = True)
files = ['Acquisition_1670928125','Acquisition_1670928767','Acquisition_1670929047','Acquisition_1670929275']
proms = [0.035,0.035,0.039,0.039]
upperlim = [1.7, 1.7, 4.1, 4.1]
runs = []
for file in range(len(files)):
    run_spe = RunInfo(['D:/Xe/DAQ/Run_1670927963.hdf5'],  specifyAcquisition = True, acquisition = files[file], do_filter = False, upper_limit = upperlim[file], baseline_correct = True, prominence = proms[file])
    runs.append(run_spe)
biases = [run.bias for run in runs] # get all the bias voltages from RunInfo (enter manually if metadata is wrong)

#%% gain calibration conversion factor (change as needed; make sure it is the correct factor for the data set)
# invC_spe_filter = 0.01957644114341406 
# invC_spe_err_filter = 8.880858907807588e-05
invC_spe_filter = 0.19261918346201742 
invC_spe_err_filter = 0.0021831140214106596
runs[3].plot_hists('158K', '0.3')
#%%
for i in range(len(runs)):
    bias = biases[i]
    runs[i].plot_hists('158K', '0.3')
    
#%%
# a_guess = 0.009546
# b_guess = -0.2595
a_guess = 0.0098
b_guess = -0.2595
range_lows = [0.034, 0.046, 0.048, 0.06]
# range_lows = [0.029, 0.035, 0.05, 0.055]
centers = [biases[i]*a_guess+b_guess for i in range(len(runs))]
range_highs = [range_lows[i] + centers[i]*5 + 0.01 for i in range(len(runs))]
range_highs[0] = 0.29
range_highs[3] = 0.54
numpeaks = [4,5,5,5]
#%% plot with peak fit

# set  conditions, temp
n= 3
T = 158
con = 'GN'
info_spe = MeasurementInfo()
info_spe.condition = con
info_spe.date = runs[n].date
info_spe.temperature = T
info_spe.bias = biases[n]
info_spe.baseline_numbins = 50
info_spe.peaks_numbins = 220
info_spe.data_type = 'h5'
wp = WaveformProcessor(info_spe, run_info_self = runs[n], run_info_solicit = run_spe_solicited, baseline_correct = True, range_low = range_lows[n], range_high = range_highs[n], center = centers[n], peak_range = (1,numpeaks[n]))
wp.process(do_spe = True, do_alpha = False)
wp.plot_peak_histograms()
wp.plot_spe()
wp.plot_both_histograms()
#%%

campaign_spe = []
for i in range(len(runs)):
    info_spe = MeasurementInfo()
    info_spe.condition = con
    info_spe.date = runs[i].date
    info_spe.temperature = T
    info_spe.bias = biases[i]
    info_spe.baseline_numbins = 50
    info_spe.peaks_numbins = 220
    info_spe.data_type = 'h5'
    wp_spe = WaveformProcessor(info_spe, run_info_self = runs[i], run_info_solicit = run_spe_solicited, baseline_correct = True, range_low = range_lows[i], range_high = range_highs[i], center = centers[i], peak_range = (1,numpeaks[i]))
    wp_spe.process(do_spe = True, do_alpha = False)
    campaign_spe.append(wp_spe)
    
#%% plots
for i in range(len(campaign_spe)):
    campaign_spe[i].plot_peak_histograms()

#%%
curr_campaign = campaign_spe

filtered_spe = SPE_data(curr_campaign, invC_spe_filter, invC_spe_err_filter, filtered = False)
filtered_spe.plot_spe(in_ov = False, absolute = False, out_file = 'D:/Raw Results/Breakdown Voltage/SPE Amplitudes/Dec2022_158K_SPE.csv')

print(filtered_spe.v_bd)
print(filtered_spe.v_bd_err)

#%%
filtered_spe.plot_spe(in_ov = True, absolute = True, out_file = None)
#%%
filtered_spe.plot_CA(out_file = 'D:/Raw Results/Correlated Avalanche Data/Dec13_2022_CA_GN.csv')

#%%
path = 'D:/Xe/AnalysisScripts/Nitrogen Dark Run 2022/158K/Images/'
for w in range(len(campaign_spe)):
    folder = path
    bias = biases[w]
    # wp_spe.plot_both_histograms(savefig = True, path = folder +'baseline_' + str(T)[:3] + '_' + str(bias)[:2] + '.png')
    campaign_spe[w].plot_peak_histograms(savefig = True, path = folder +'gauss_' + str(T)[:3] + '_' + str(bias)[:2] + '_revision.png')
    campaign_spe[w].plot_spe(savefig = True, path = folder + 'line_' +str(T)[:3] + '_' + str(bias)[:2] + '_revision.png')
    # wp_spe.plot_both_histograms(savefig = True, path = folder +'baseline_' + str(T)[:3] + '_' + str(bias)[:2] + '.svg')
    # wp_spe.plot_peak_histograms(savefig = True, path = folder +'gauss_' + str(T)[:3] + '_' + str(bias)[:2] + '.svg')